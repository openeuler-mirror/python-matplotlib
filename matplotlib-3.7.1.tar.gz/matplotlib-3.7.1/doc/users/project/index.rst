.. redirect-from:: /users/backmatter

Project information
-------------------

.. toctree::
    :maxdepth: 2

    mission.rst
    history.rst
    citing.rst
    license.rst
    credits.rst
