**************************************
``matplotlib.backends.backend_webagg``
**************************************

.. automodule:: matplotlib.backends.backend_webagg
   :members:
   :undoc-members:
   :show-inheritance:
