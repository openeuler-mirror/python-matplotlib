API Changes for 3.5.0
=====================

.. contents::
   :local:
   :depth: 1

.. include:: /api/prev_api_changes/api_changes_3.5.0/behaviour.rst

.. include:: /api/prev_api_changes/api_changes_3.5.0/deprecations.rst

.. include:: /api/prev_api_changes/api_changes_3.5.0/removals.rst

.. include:: /api/prev_api_changes/api_changes_3.5.0/development.rst
