********************************
``matplotlib.projections.polar``
********************************

.. automodule:: matplotlib.projections.polar
   :members:
   :show-inheritance:
