******************************
``matplotlib.projections.geo``
******************************

.. automodule:: matplotlib.projections.geo
   :members:
   :show-inheritance:
