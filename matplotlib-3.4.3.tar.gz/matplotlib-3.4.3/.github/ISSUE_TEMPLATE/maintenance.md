---
name: Maintenance
about: Help improve performance, usability and/or consistency.
labels: Maintenance
---

### Describe the issue

**Summary**

<!-- A short 1-2 sentences that succinctly describe what could be improved -->

### Proposed fix

