
:mod:`matplotlib.backends.backend_tkagg`
========================================

.. automodule:: matplotlib.backends.backend_tkagg
   :members:
   :undoc-members:
   :show-inheritance:

:mod:`matplotlib.backends.backend_tkcairo`
==========================================

.. automodule:: matplotlib.backends.backend_tkcairo
   :members:
   :undoc-members:
   :show-inheritance:
