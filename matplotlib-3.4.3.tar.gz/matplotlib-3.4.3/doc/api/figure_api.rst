*********************
``matplotlib.figure``
*********************

.. currentmodule:: matplotlib.figure

.. automodule:: matplotlib.figure
   :members:
   :inherited-members:
