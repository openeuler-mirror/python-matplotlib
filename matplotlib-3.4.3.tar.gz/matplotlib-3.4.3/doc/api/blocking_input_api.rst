*****************************
``matplotlib.blocking_input``
*****************************

.. automodule:: matplotlib.blocking_input
   :members:
   :undoc-members:
   :show-inheritance:
