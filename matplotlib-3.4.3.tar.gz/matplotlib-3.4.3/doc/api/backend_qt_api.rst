**NOTE** These backends are not documented here, to avoid adding a dependency
to building the docs.

.. redirect-from:: /api/backend_qt4agg_api
.. redirect-from:: /api/backend_qt4cairo_api
.. redirect-from:: /api/backend_qt5agg_api
.. redirect-from:: /api/backend_qt5cairo_api

:mod:`matplotlib.backends.backend_qt4agg`
=========================================

.. module:: matplotlib.backends.backend_qt4agg

:mod:`matplotlib.backends.backend_qt4cairo`
===========================================

.. module:: matplotlib.backends.backend_qt4cairo

:mod:`matplotlib.backends.backend_qt5agg`
=========================================

.. module:: matplotlib.backends.backend_qt5agg

:mod:`matplotlib.backends.backend_qt5cairo`
===========================================

.. module:: matplotlib.backends.backend_qt5cairo
