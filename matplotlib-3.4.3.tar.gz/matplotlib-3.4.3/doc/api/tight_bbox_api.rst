*************************
``matplotlib.tight_bbox``
*************************

.. automodule:: matplotlib.tight_bbox
   :members:
   :undoc-members:
   :show-inheritance:
