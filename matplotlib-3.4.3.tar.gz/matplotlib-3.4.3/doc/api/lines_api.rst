********************
``matplotlib.lines``
********************

.. currentmodule:: matplotlib.lines

.. automodule:: matplotlib.lines
   :no-members:
   :no-inherited-members:

Classes
-------

.. autosummary::
   :toctree: _as_gen/
   :template: autosummary.rst

   Line2D
   VertexSelector

Functions
---------

.. autosummary::
   :toctree: _as_gen/
   :template: autosummary.rst

   segment_hits
   