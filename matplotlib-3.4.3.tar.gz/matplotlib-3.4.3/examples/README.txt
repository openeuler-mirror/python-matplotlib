.. _examples-index:

.. _gallery:

=======
Gallery
=======

This gallery contains examples of the many things you can do with
Matplotlib. Click on any image to see the full image and source code.

For longer tutorials, see our `tutorials page <../tutorials/index.html>`_.
You can also find `external resources <../resources/index.html>`_ and
a `FAQ <../faq/index.html>`_ in our `user guide <../contents.html>`_.
