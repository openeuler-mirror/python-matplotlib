*************************
``matplotlib.tight_bbox``
*************************

.. attention::
    This module is considered internal.

    Its use is deprecated and it will be removed in a future version.

.. automodule:: matplotlib._tight_bbox
   :members:
   :undoc-members:
   :show-inheritance:
