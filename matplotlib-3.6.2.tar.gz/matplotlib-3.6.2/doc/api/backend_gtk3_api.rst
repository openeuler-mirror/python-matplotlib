:mod:`.backend_gtk3agg`, :mod:`.backend_gtk3cairo`
==================================================

**NOTE** These backends are not documented here, to avoid adding a dependency
to building the docs.

.. redirect-from:: /api/backend_gtk3agg_api
.. redirect-from:: /api/backend_gtk3cairo_api

.. module:: matplotlib.backends.backend_gtk3agg
.. module:: matplotlib.backends.backend_gtk3cairo
