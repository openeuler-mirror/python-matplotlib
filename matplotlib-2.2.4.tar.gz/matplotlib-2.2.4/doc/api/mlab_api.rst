****
mlab
****


:mod:`matplotlib.mlab`
=======================

.. automodule:: matplotlib.mlab
   :members:
   :undoc-members:
   :show-inheritance:
