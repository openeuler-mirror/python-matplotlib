*************************
legend and legend_handler
*************************


:mod:`matplotlib.legend`
=========================

.. automodule:: matplotlib.legend
   :members:
   :undoc-members:
   :show-inheritance:

:mod:`matplotlib.legend_handler`
================================
.. automodule:: matplotlib.legend_handler
      :members:
      :undoc-members:
